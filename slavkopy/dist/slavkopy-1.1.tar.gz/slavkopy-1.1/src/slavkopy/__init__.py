import code, os
py = code
print(py.hello(os.environ.get('USER', os.environ.get('USERNAME'))))
def hello(name):
    a = "hello" + name
    return a